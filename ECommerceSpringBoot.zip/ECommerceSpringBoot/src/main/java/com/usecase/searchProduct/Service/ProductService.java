package com.usecase.searchProduct.Service;

import java.util.List;

import com.usecase.searchProduct.DAO.ProductResponseDAO;
import com.usecase.searchProduct.DAO.ProductSearchDAO;
import com.usecase.searchProduct.entity.Product;
import com.usecase.searchProduct.exception.InvalidArgumentException;

public interface ProductService {
	public List<ProductResponseDAO> searchProduct(ProductSearchDAO  productRequestDao)throws Exception ;
	public List<ProductResponseDAO> sortProduct() throws InvalidArgumentException;
	public List<ProductResponseDAO> searchProductLike(ProductSearchDAO  productRequestDao) throws InvalidArgumentException;
	public List<ProductResponseDAO> searchProductNotLike(ProductSearchDAO  productRequestDao) throws InvalidArgumentException;
	public List<ProductResponseDAO> searchProductNameStartsWith(ProductSearchDAO productRequestDao) throws InvalidArgumentException;
	public List<ProductResponseDAO> searchProductNameEndsWith(ProductSearchDAO productRequestDao) throws InvalidArgumentException;
	public List<ProductResponseDAO> searchProductNameContains(ProductSearchDAO productRequestDao) throws InvalidArgumentException;
	public List<ProductResponseDAO> searchProductNameIsContaining(ProductSearchDAO productRequestDao) throws InvalidArgumentException;
	public List<ProductResponseDAO> searchProductNameContainingIgnoreCase(ProductSearchDAO productRequestDao) throws InvalidArgumentException;
	public List<ProductResponseDAO> searchProductNameNotContaining(ProductSearchDAO productRequestDao) throws InvalidArgumentException;

}
