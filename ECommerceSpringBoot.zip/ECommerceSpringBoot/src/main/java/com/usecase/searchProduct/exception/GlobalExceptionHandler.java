package com.usecase.searchProduct.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler{

	
	
	@ExceptionHandler(value = AccountNumberNotFoundException.class)
	   public ResponseEntity<Object> exception(AccountNumberNotFoundException exception) {
	      return new ResponseEntity<>("Account not found", HttpStatus.NOT_FOUND);
	   }
	
	@ExceptionHandler(value = InsufficientBalanceException.class)
	   public ResponseEntity<Object> exception(InsufficientBalanceException exception) {
	      return new ResponseEntity<>("Balance is Insufficient in user Account", HttpStatus.NOT_FOUND);
	   }
	
	
	@ExceptionHandler(value = InvalidArgumentException.class)
	   public ResponseEntity<Object> exception(InvalidArgumentException exception) {
	      return new ResponseEntity<>("Arguments not found", HttpStatus.NOT_FOUND);
	   }
	
	@ExceptionHandler(value = InvalidUserException.class)
	   public ResponseEntity<Object> exception(InvalidUserException exception) {
	      return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
	   }
}
