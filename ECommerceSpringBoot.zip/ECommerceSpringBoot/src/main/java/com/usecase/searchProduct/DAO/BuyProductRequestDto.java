package com.usecase.searchProduct.DAO;

import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class BuyProductRequestDto {

	@NotNull(message="Please provide user id")
	private long userId;
	
	@Digits(integer = 10, fraction = 1, message = "InValid accountNumber")
	private long accountNo;
	
	private List<BuyProductDto> products;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public List<BuyProductDto> getProducts() {
		return products;
	}

	public void setProducts(List<BuyProductDto> products) {
		this.products = products;
	}
	
	
	



}
