package com.usecase.searchProduct.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.usecase.searchProduct.entity.OrderDetails;

@Repository
public interface OrderHistoryRepository extends JpaRepository<OrderDetails, Long>{

	@Query("select od from OrderDetails od where od.orders.orderId=:orderId")
	List<OrderDetails> findByOrders(long orderId);

	
}
