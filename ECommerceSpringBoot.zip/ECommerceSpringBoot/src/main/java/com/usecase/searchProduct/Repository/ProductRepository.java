package com.usecase.searchProduct.Repository;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.usecase.searchProduct.DAO.ProductResponseDAO;
import com.usecase.searchProduct.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository <Product, Integer> {
	
	/*
	 * @Query("select pro from Product pro where pro.productName=:productName or pro.category.name=:category"
	 * ) List<Product> findByProductNameContainsOrCategoryContains(String
	 * productName,String category);
	 */
	
	List<Product> findByProductNameOrProductCategory(String productName,String productCategory);
	List<Product> findByOrderByProductNameAsc();
	List<Product> findByProductNameLike(String productName);
	List<Product> findByProductNameNotLike(String productName);
	List<Product> findByProductNameStartsWith(String productName);
	List<Product> findByProductNameEndsWith(String productName);
	List<Product> findByProductNameContains(String productName);
	List<Product> findByProductNameIsContaining(String productName);
	List<Product> findByProductNameContainingIgnoreCase(String productName);
	List<Product> findByProductNameNotContaining(String productName);

}
