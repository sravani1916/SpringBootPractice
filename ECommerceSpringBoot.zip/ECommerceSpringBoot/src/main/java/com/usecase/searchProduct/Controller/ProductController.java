package com.usecase.searchProduct.Controller;

import java.util.*;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.usecase.searchProduct.DAO.BuyProductRequestDto;
import com.usecase.searchProduct.DAO.OrderHistoryResponseDto;
import com.usecase.searchProduct.DAO.ProductResponseDAO;
import com.usecase.searchProduct.DAO.ProductSearchDAO;
import com.usecase.searchProduct.Service.BuyProductService;
import com.usecase.searchProduct.Service.OrderHistoryService;
import com.usecase.searchProduct.Service.ProductService;
import com.usecase.searchProduct.entity.Product;

@Validated
@RestController
@RequestMapping("/ecommerce")

public class ProductController {

	@Autowired
	private ProductService productService;

	@Autowired
	private BuyProductService buyProductService;

	@Autowired
	private OrderHistoryService orderHistoryService;

	/*
	 * @PostMapping("/products") public List<Product> list() { return
	 * service.listAll(); }
	 */
	@PostMapping("/searchProduct")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProduct(@Valid @RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProduct(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	@PostMapping("/productNameLike")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProductLike(@RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProductLike(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	@PostMapping("/productNameNotLike")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProductNotLike(@RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProductNotLike(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	
	
	
	@PostMapping("/productNameStartsWith")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProductNameStartsWith(@RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProductNameStartsWith(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	@PostMapping("/productNameEndsWith")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProductNameEndsWith(@RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProductNameEndsWith(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	@PostMapping("/productNameContains")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProductNameContains(@RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProductNameContains(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	@PostMapping("/productNameIsContaining")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProductNameIsContaining(@RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProductNameIsContaining(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	@PostMapping("/productNameContainsIgnoreCase")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProductNameContainsIgnoreCase(@RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProductNameContainingIgnoreCase(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	@PostMapping("/productNameNotContains")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> searchProductNameNotContains(@RequestBody ProductSearchDAO productSearchDto) throws Exception {

		List<ProductResponseDAO> productResponseDto = new ArrayList<ProductResponseDAO>();
		productResponseDto = productService.searchProductNameNotContaining(productSearchDto);
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productResponseDto, HttpStatus.CREATED);

	}
	
	@GetMapping("/sortProduct")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<List<ProductResponseDAO>> sortProduct() throws Exception {

		List<ProductResponseDAO> productSortResponseDto = new ArrayList<ProductResponseDAO>();
		productSortResponseDto = productService.sortProduct();
		//ResponseEntity<List<ProductResponseDAO>> respEntity = new ResponseEntity<List<ProductResponseDAO>>(productResponseDto, HttpStatus.CREATED);
		return new ResponseEntity<>(productSortResponseDto, HttpStatus.CREATED);

	}

	@PostMapping("/buyProducts")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<String> purchaseProduct(@Valid @RequestBody BuyProductRequestDto requestDto) throws Exception {
		/*
		 * String order=buyProductService.purchaseProduct(requestDto);
		 * 
		 * if(order==false) { return "issue while placing the order"; } return
		 * "order successfully placed";
		 * 
		 * return order;
		 */
		
		return new ResponseEntity<String>(buyProductService.purchaseProduct(requestDto), HttpStatus.OK);

	}

	/*
	 * @GetMapping("/orderHistory/{userid}") public List<OrderHistoryResponseDto>
	 * getorderdetails(@PathVariable("userid") long userid) throws
	 * InvalidUserException, ParseException { System.out.println("@@@@@@@ " +
	 * userid); List<OrderHistoryResponseDto> orderHistoryResponseDto =
	 * orderHistoryService.getOrderDetails(userid); return orderHistoryResponseDto;
	 * }
	 */
	
	
	@GetMapping("/orderHistory/{userId}")
	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	public ResponseEntity<?> orderHistory(@PathVariable("userId") long userId) throws Exception
	{
		
		return new ResponseEntity<List<OrderHistoryResponseDto>>(orderHistoryService.getOrderDetails(userId), HttpStatus.OK);

  						 
	}
	
	
	
}
