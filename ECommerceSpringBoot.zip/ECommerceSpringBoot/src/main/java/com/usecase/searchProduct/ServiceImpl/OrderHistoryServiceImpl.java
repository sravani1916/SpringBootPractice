package com.usecase.searchProduct.ServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usecase.searchProduct.DAO.OrderHistoryResponseDto;
import com.usecase.searchProduct.DAO.ProductDto;
import com.usecase.searchProduct.Repository.OrderHistoryRepository;
import com.usecase.searchProduct.Repository.UserRepository;
import com.usecase.searchProduct.Service.OrderHistoryService;
import com.usecase.searchProduct.entity.OrderDetails;
import com.usecase.searchProduct.entity.Orders;
import com.usecase.searchProduct.entity.User;
import com.usecase.searchProduct.exception.InvalidUserException;

@Service
public class OrderHistoryServiceImpl implements OrderHistoryService{
	 private static final Logger logger = LoggerFactory.getLogger(OrderHistoryServiceImpl.class);

	@Autowired
	public OrderHistoryRepository  orderHistoryRepository;
	
	@Autowired
    public OrderHistoryRepository  orderRepository;
	
	@Autowired	
    public UserRepository  userRespository;
	
	@Override
	public List<OrderHistoryResponseDto> getOrderDetails(long userId) throws InvalidUserException {
		List<OrderDetails> orderDetails=new ArrayList<OrderDetails>();
		List<OrderHistoryResponseDto> OrderHistoryResDtoList=new ArrayList<OrderHistoryResponseDto>();
		List<OrderHistoryResponseDto> OrderHistoryResDtoList2=new ArrayList<OrderHistoryResponseDto>();
		System.out.println("Input user ID "+userId);
		
		//get the userId details from user table
		Optional<User> userIdvalue=userRespository.findById(userId);
		 
		System.out.println("User ID from DB "+userIdvalue);
		
		if(userIdvalue.isPresent())
		{
	    	User user=userIdvalue.get();
			List<Orders> orderlist =user.getOrderId();
			if(orderlist!=null)
			{
			for(Orders orderdetl:orderlist)
			{
				long orderId=orderdetl.getOrderId();
				logger.info("orderid-----"+orderId);
				orderDetails=orderHistoryRepository.findByOrders(orderId);
			for( OrderDetails orderDetls:orderDetails)
			{
				// copyProperties will copy order details from orderDetls to orderHistoryResponseDto
				OrderHistoryResponseDto orderHistoryResponseDto=new OrderHistoryResponseDto();
				BeanUtils.copyProperties(orderDetls,orderHistoryResponseDto);
				ProductDto productDto=new ProductDto();
				List<ProductDto> productDtolist=new ArrayList<ProductDto>();
				productDto.setProductName(orderDetls.getProduct().getProductName());
				productDto.setQuantity(orderDetls.getProduct().getQuantity());
				productDto.setUnitPrice(orderDetls.getProduct().getProductPrice());
				productDtolist.add(productDto);
				orderHistoryResponseDto.setOrderId(orderDetls.getOrders().getOrderId());
				orderHistoryResponseDto.setTotalPrice(orderDetls.getPrice());
				orderHistoryResponseDto.setOrderDate(orderDetls.getOrders().getDatetime());
				orderHistoryResponseDto.setProductdto(productDtolist);
				OrderHistoryResDtoList.add(orderHistoryResponseDto);		
			}
			logger.info("order-----"+orderDetails);
			}
			OrderHistoryResDtoList2.addAll(OrderHistoryResDtoList);
			}
			else
			{
				throw new InvalidUserException("This user has no order history");
				
			}
			
		}
		else
		{
			throw new InvalidUserException("user id is invalid");
			
		}
		
		return OrderHistoryResDtoList;
	
	}

}
