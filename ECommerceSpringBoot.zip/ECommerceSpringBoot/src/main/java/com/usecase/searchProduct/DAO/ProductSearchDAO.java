package com.usecase.searchProduct.DAO;

import javax.validation.constraints.*;

public class ProductSearchDAO {

	// @Size(min = 3, max = 200,message = " fristName should less then 200 character only")
	@NotBlank(message = "product should not be empty")
	private String productName;
	
	
	@NotBlank(message = "categoryName should not be empty")
	//@Size(min = 2, max = 200,message = " fristName should less then 200 character only")
	private String categoryName;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

}
