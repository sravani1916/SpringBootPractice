package com.usecase.searchProduct.Service;

import java.util.List;

import com.usecase.searchProduct.DAO.OrderHistoryResponseDto;
import com.usecase.searchProduct.exception.InvalidUserException;

public interface OrderHistoryService {
	List<OrderHistoryResponseDto> getOrderDetails(long userId) throws InvalidUserException;

}
