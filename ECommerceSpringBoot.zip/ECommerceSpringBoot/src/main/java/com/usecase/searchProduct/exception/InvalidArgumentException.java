package com.usecase.searchProduct.exception;

public class InvalidArgumentException  extends Exception{
	private static final long serialVersionUID = 1L;

	public InvalidArgumentException() {
		super();

	}
	
	public InvalidArgumentException(String message) {
		super(message);

	}

	public InvalidArgumentException(String message, Throwable t) {
		super(message, t);

	}
}
