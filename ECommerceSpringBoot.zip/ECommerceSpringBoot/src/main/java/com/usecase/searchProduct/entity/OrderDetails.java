package com.usecase.searchProduct.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="order_details")
public class OrderDetails {

	@Id
	@GeneratedValue(strategy =javax.persistence.GenerationType.IDENTITY)
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private long orderdetailsId;
	private int quantity;
	private double price;
	//private Product product_Id;
	
	@ManyToOne
	@JoinColumn(name="order_Id")
	private Orders orders;
	
	@ManyToOne
	@JoinColumn(name="product_Id")
	private Product product;

	
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public long getOrderdetailsId() {
		return orderdetailsId;
	}
	public void setOrderdetailsId(long orderdetailsId) {
		this.orderdetailsId = orderdetailsId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Orders getOrders() {
		return orders;
	}
	public void setOrders(Orders orders) {
		this.orders = orders;
	}
	
	
	
	
}

