package com.usecase.searchProduct.exception;

public class AccountNumberNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AccountNumberNotFoundException() {
		super();

	}
	
	public AccountNumberNotFoundException(String message) {
		super(message);

	}

	public AccountNumberNotFoundException(String message, Throwable t) {
		super(message, t);

	}
}
