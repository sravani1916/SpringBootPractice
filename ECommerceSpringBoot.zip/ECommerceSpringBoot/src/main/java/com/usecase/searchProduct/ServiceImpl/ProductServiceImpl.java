package com.usecase.searchProduct.ServiceImpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.usecase.searchProduct.DAO.ProductResponseDAO;
import com.usecase.searchProduct.DAO.ProductSearchDAO;
import com.usecase.searchProduct.Repository.ProductRepository;
import com.usecase.searchProduct.Service.ProductService;
import com.usecase.searchProduct.entity.Product;
import com.usecase.searchProduct.exception.InvalidArgumentException;

@Service
public class ProductServiceImpl implements ProductService {
	private static final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

	@Autowired
	ProductRepository productRepository;	
	
	
	@Override
	public List<ProductResponseDAO> searchProduct(ProductSearchDAO productSearchDao) throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productSearchDao.getProductName();
		String category=productSearchDao.getCategoryName();
		
		if(productName.isEmpty() && category.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null || category!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameOrProductCategory(productName,category);
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	
	}


	@Override
	public List<ProductResponseDAO> sortProduct() throws InvalidArgumentException {
		List<ProductResponseDAO> productNameSort=new ArrayList<ProductResponseDAO>();
		List<Product> productSortList=new ArrayList<Product>();
	
		productSortList = productRepository.findByOrderByProductNameAsc();
		if(!productSortList.isEmpty()) {
			for(Product productSortDetails : productSortList) 
			{ 
				ProductResponseDAO productSortDto=new ProductResponseDAO(); 
				productSortDto.setProductName(productSortDetails.getProductName());
				productSortDto.setProductCategory(productSortDetails.getCategory().getName());
				productSortDto.setProductPrice(productSortDetails.getProductPrice());
				productSortDto.setQuantity(productSortDetails.getQuantity());
				productNameSort.add(productSortDto); 
				
			} 
			return productNameSort;
		}else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}

	}


	@Override
	public List<ProductResponseDAO> searchProductLike(ProductSearchDAO productRequestDao)
			throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productRequestDao.getProductName();
		
		
		if(productName.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameLike("%"+productName+"%");
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	
	
	}
	
	@Override
	public List<ProductResponseDAO> searchProductNotLike(ProductSearchDAO productRequestDao) throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productRequestDao.getProductName();
		
		
		if(productName.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameNotLike("%"+productName+"%");
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	
	
	}


	@Override
	public List<ProductResponseDAO> searchProductNameStartsWith(ProductSearchDAO productRequestDao)
			throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productRequestDao.getProductName();
		
		
		if(productName.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameStartsWith(""+productName+"");
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	
	}


	@Override
	public List<ProductResponseDAO> searchProductNameEndsWith(ProductSearchDAO productRequestDao)
			throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productRequestDao.getProductName();
		
		
		if(productName.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameEndsWith(""+productName+"");
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	
	}


	@Override
	public List<ProductResponseDAO> searchProductNameContains(ProductSearchDAO productRequestDao)
			throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productRequestDao.getProductName();
		
		
		if(productName.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameContains(""+productName+"");
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	
	}


	@Override
	public List<ProductResponseDAO> searchProductNameContainingIgnoreCase(ProductSearchDAO productRequestDao)
			throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productRequestDao.getProductName();
		
		
		if(productName.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameContainingIgnoreCase(""+productName+"");
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	}


	@Override
	public List<ProductResponseDAO> searchProductNameNotContaining(ProductSearchDAO productRequestDao)
			throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productRequestDao.getProductName();
		
		
		if(productName.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameNotContaining(""+productName+"");
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	}


	@Override
	public List<ProductResponseDAO> searchProductNameIsContaining(ProductSearchDAO productRequestDao)
			throws InvalidArgumentException {
		List<ProductResponseDAO> productResponseDao=new ArrayList<ProductResponseDAO>();
		List<Product> productlist=new ArrayList<Product>();
		
		
		String productName=productRequestDao.getProductName();
		
		
		if(productName.isEmpty()) {
			throw new InvalidArgumentException("Please enter atleast one input");
		}
		if(productName!=null )
		{	
			//logger.info("enter block");
			productlist= productRepository.findByProductNameIsContaining(""+productName+"");
			
			if(!productlist.isEmpty()) {		
			for(Product productDetails : productlist) 
			{ 
				ProductResponseDAO productResDto=new ProductResponseDAO(); 
				productResDto.setProductName(productDetails.getProductName());
				productResDto.setProductCategory(productDetails.getCategory().getName());
				productResDto.setProductPrice(productDetails.getProductPrice());
				productResDto.setQuantity(productDetails.getQuantity());
				productResponseDao.add(productResDto); 
				
			} 
			}else {
				
				throw new InvalidArgumentException("Please provide valid input details");
			}
		}
		else
		{
			logger.info("Invalid input");
			throw new InvalidArgumentException("Invalid input");
		}
		return productResponseDao;
	}
	
	
	
	
	
	
}
