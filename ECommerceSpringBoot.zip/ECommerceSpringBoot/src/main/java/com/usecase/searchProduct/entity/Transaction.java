package com.usecase.searchProduct.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="transaction_details")
public class Transaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="transaction_id")
	private long transId;
	
	@Column(name="amount")
	private double amount;
	
	@Column(name="from_account")
	private long from_account;
	
	@Column(name="to_account")
	private long to_account;
	
	@Column(name="transactiontime")
	private Date transactiontime; 
	
	@Column(name="type")
	private String type;

	public long getTransId() {
		return transId;
	}

	public void setTransId(long transId) {
		this.transId = transId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public long getFrom_account() {
		return from_account;
	}

	public void setFrom_account(long from_account) {
		this.from_account = from_account;
	}

	public long getTo_account() {
		return to_account;
	}

	public void setTo_account(long to_account) {
		this.to_account = to_account;
	}

	public Date getTransactiontime() {
		return transactiontime;
	}

	public void setTransactiontime(Date transactiontime) {
		this.transactiontime = transactiontime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	

}
