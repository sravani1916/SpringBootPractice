package com.usecase.searchProduct.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.usecase.searchProduct.entity.AccountDetails;


public interface AccountDetailsRepository extends JpaRepository<AccountDetails, Long>{

	//@Query("select accdetl from AccountDetails accdetl where account_number=:accountNumber")
	public AccountDetails findByAccountNumber(long accountNumber);

}
