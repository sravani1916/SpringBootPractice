package com.usecase.searchProduct.ServiceImpl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usecase.searchProduct.DAO.BuyProductDto;
import com.usecase.searchProduct.DAO.BuyProductRequestDto;
import com.usecase.searchProduct.DAO.FundTransferRequestDto;
import com.usecase.searchProduct.Repository.AccountDetailsRepository;
import com.usecase.searchProduct.Repository.OrderHistoryRepository;
import com.usecase.searchProduct.Repository.OrderRepository;
import com.usecase.searchProduct.Repository.ProductRepository;
import com.usecase.searchProduct.Repository.TransactionRepository;
import com.usecase.searchProduct.Repository.UserRepository;
import com.usecase.searchProduct.Service.BuyProductService;
import com.usecase.searchProduct.entity.AccountDetails;
import com.usecase.searchProduct.entity.OrderDetails;
import com.usecase.searchProduct.entity.Orders;
import com.usecase.searchProduct.entity.Product;
import com.usecase.searchProduct.entity.Transaction;
import com.usecase.searchProduct.entity.User;
import com.usecase.searchProduct.exception.AccountNumberNotFoundException;
import com.usecase.searchProduct.exception.InsufficientBalanceException;
import com.usecase.searchProduct.exception.InvalidArgumentException;
import com.usecase.searchProduct.exception.InvalidUserException;

@Service
public class BuyProductServiceImpl implements BuyProductService{
	   private static final Logger logger = LoggerFactory.getLogger(BuyProductServiceImpl.class);

	
	@Autowired
	ProductRepository productRepository;	
	@Autowired
	UserRepository userRepository;
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	AccountDetailsRepository accountRepository;
	@Autowired
	OrderHistoryRepository orderHistoryRepository;
	@Autowired
	TransactionRepository transactionRepository;
	
	@Override
	public String purchaseProduct(BuyProductRequestDto buyproductDto) throws AccountNumberNotFoundException, InsufficientBalanceException, InvalidUserException {
		// TODO Auto-generated method stub
		
		List<BuyProductDto> products = buyproductDto.getProducts();
		AccountDetails accountDetails = accountRepository.findByAccountNumber(buyproductDto.getAccountNo());   //getAccountDetails(buyproductDto.getAccountNo());
		Optional<User> user = userRepository.findById(buyproductDto.getUserId());

		Date date = new Date();
		//Check whether the user is present in Database or not; If not present throw an exception 
		if (!user.isPresent()) {
			logger.info("User Not found");
			throw new InvalidUserException("User Not found");
		} 
		
		// Check for the AC details 
		  if (accountDetails == null) { //logger.info("Account number Not found");
		  throw new AccountNumberNotFoundException("Please provide valid Account number"); 
		  }
		  
		// get total amount
		// Products will have the Input given by the user
			double sum = 0;
			for (BuyProductDto productDto : products) {
				Optional<Product> product = productRepository.findById(productDto.getProductId());
				int Quantity = productDto.getQuantity();
				// Check if the product is present in DB
				if (product.isPresent()) {
				// Check if the Quantity requested by user is >0
					if (Quantity > 0) {
						
				// Check if the quantity present in DB is > Quantity requested by user
						if (product.get().getQuantity() >= productDto.getQuantity()) {
							sum = sum + (productDto.getQuantity() * product.get().getProductPrice());
							//product.get().setQuantity(product.get().getQuantity()-productDto.getQuantity());
							//productRepository.save(product);
						} else {
							throw new AccountNumberNotFoundException("Ordered quantity is: "+productDto.getQuantity()+
									"/n Available quantity is: "+product.get().getQuantity() +"/n Please order a lesser quantity" );
						}
					} else {
						throw new AccountNumberNotFoundException("Please provide valid quantity");
					}

				}

				else {
					throw new NullPointerException("product id  not found in db");
				}
			}
			
			// If amount is insufficient then return false
			if (accountDetails.getAvailable_balance() < sum) {
	        throw new InsufficientBalanceException("balance not available");
			}
			
			// saving order details
			System.out.println("USer ID ######### "+user.get().getUserId());
			Orders order = new Orders();
			if (user.isPresent()) {
				try {
					order.setUser(user.get());					
					order.setTotalPrice(sum);
					order.setDatetime(date);
				
					orderRepository.save(order);
				} catch (Exception exception) {
					logger.error("Exception occurred while saving the order", exception);
					return exception.getMessage();
				}

				
				// Update the product quantity in Product table
				for (BuyProductDto productDto : products) {
					Optional<Product> product = productRepository.findById(productDto.getProductId());
					if (product.isPresent()) {
						try {
							Product product1 = productRepository.findById(productDto.getProductId()).get();
							product.get().setQuantity(product.get().getQuantity() - productDto.getQuantity());							
							OrderDetails orderDetails = new OrderDetails();						
							orderDetails.setOrders(order);
							orderDetails.setQuantity(productDto.getQuantity());
							orderDetails.setPrice(productDto.getQuantity() * product.get().getProductPrice());				
							orderDetails.setProduct(product.get());
							orderHistoryRepository.save(orderDetails);
						} catch (Exception exception) {
							logger.error("Exception occurred while saving the order", exception);
							return exception.getMessage();
						} 
					}

				}

				// Transaction amount
			    //if(Optional.ofNullable(order).isPresent()) {
				try {
					FundTransferRequestDto transaction = new FundTransferRequestDto();					
					transaction.setFromAccount(buyproductDto.getAccountNo());
					transaction.setAmount(sum);
					transaction.setToAccount(987654321);// set the default to account number
					
					AccountDetails fromAccount = accountRepository.findByAccountNumber(transaction.getFromAccount());
					AccountDetails toAccount = accountRepository.findByAccountNumber(transaction.getToAccount());
				/*
				 * Transaction sourceAcc= new Transaction(); Transaction targetAcc= new
				 * Transaction();
				 * 
				 * //inserting records to transactions tables for source account transaction
				 * Timestamp ts = new Timestamp(date.getTime()); sourceAcc.setAmount(sum);
				 * sourceAcc.setFrom_account(fromAccount.getAccountNumber());
				 * sourceAcc.setTransactiontime(ts); sourceAcc.setType("Debit");
				 * transactionRepository.save(sourceAcc);
				 * 
				 * //inserting records to transactions tables for target account transaction
				 * targetAcc.setAmount(sum);
				 * targetAcc.setTo_account(toAccount.getAccountNumber());
				 * targetAcc.setTransactiontime(ts); targetAcc.setType("Credit");
				 * transactionRepository.save(targetAcc);
				 */
					
					System.out.println("Available bal "+fromAccount.getAvailable_balance()+ " Toatal amount "+transaction.getAmount());
					if(fromAccount.getAvailable_balance() >= transaction.getAmount()) {
						double fromAvalBal = fromAccount.getAvailable_balance() - transaction.getAmount();
						double toAvalBal = toAccount.getAvailable_balance() + transaction.getAmount();
						fromAccount.setAvailable_balance(fromAvalBal);
						toAccount.setAvailable_balance(toAvalBal);
						
						accountRepository.save(fromAccount);
						accountRepository.save(toAccount);
					}
									
				} catch (Exception exception) {
					logger.error("Bank details is not available", exception);
					return exception.getMessage();
				}

				}

			//}

		return "Order placed successfully with order id "+order.getOrderId();
	}


}
