package com.usecase.searchProduct.exception;

public class InsufficientBalanceException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public InsufficientBalanceException()
	  {
		  super();
	  }

	public InsufficientBalanceException(String message) {
		super(message);

	}

	public InsufficientBalanceException(String message, Throwable t) {
		super(message, t);

	}
}
