package com.usecase.searchProduct.DAO;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class BuyProductDto {

	@NotNull(message = "please provide productid ")
	@Size(min = 1, max = 10, message = "please provide productid")
	private int productId;
	
	@NotNull(message = "please provide quantity details ")
	@Size(min = 1, max = 10, message = "please provide quantity details")
	private int quantity;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	
}
