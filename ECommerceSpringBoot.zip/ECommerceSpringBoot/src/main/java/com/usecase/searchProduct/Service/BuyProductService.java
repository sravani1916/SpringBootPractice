package com.usecase.searchProduct.Service;

import com.usecase.searchProduct.DAO.BuyProductRequestDto;

public interface BuyProductService {

	public String purchaseProduct(BuyProductRequestDto buyproductDto) throws Exception;
}
