package com.usecase.searchProduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommerceSpringBootApplication.class, args);
	}

}
