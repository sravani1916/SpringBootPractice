package com.usecase.searchProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
