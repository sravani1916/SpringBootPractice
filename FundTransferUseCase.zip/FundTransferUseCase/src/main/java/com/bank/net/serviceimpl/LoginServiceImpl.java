package com.bank.net.serviceimpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bank.net.dto.LoginDTO;
import com.bank.net.dto.UserDetailsDTO;
import com.bank.net.exception.InvalidCredentialsException;
import com.bank.net.model.User;
import com.bank.net.repository.UserCredentialsRepository;
import com.bank.net.repository.UserRepository;
import com.bank.net.service.LoginService;



@Service
public class LoginServiceImpl implements LoginService{

	private static final Logger logger = LoggerFactory.getLogger(LoginServiceImpl.class);

	@Autowired
	UserCredentialsRepository userCredRepo;
	
	@Autowired
	UserRepository userRepo;

	@Override
	public ResponseEntity<String> getCustomerDetails(LoginDTO userCredentials) {
		logger.info("inside getCustomerDetails method");
		String userName = userCredentials.getUsername();
		String password = userCredentials.getPassword();
		System.out.println("user name "+userName);

		if(userCredRepo.findByUserNameAndPassword(userName, password)==null)
			throw new InvalidCredentialsException("Authetication Failed! Please provide valid User Name or Password ");
		
		
		/*
		 * User user = new User(); user = userRepo.findByUserName(userName);
		 * UserDetailsDTO userDetails = new UserDetailsDTO();
		 * //userDetails.setAccountno(user.getAccountDetails());
		 * userDetails.setAccountType(user.getAccounttype());
		 * userDetails.setFirstname(user.getFirstName());
		 * userDetails.setLastname(user.getLastName());
		 */
		
		return new ResponseEntity<>("Authetication Success", HttpStatus.OK);
	}

	
}
