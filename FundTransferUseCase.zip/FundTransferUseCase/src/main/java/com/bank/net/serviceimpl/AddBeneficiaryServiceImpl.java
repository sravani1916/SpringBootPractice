package com.bank.net.serviceimpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bank.net.dto.BeneficiaryDTO;
import com.bank.net.exception.UserNotFoundException;
import com.bank.net.model.Beneficiary;
import com.bank.net.model.User;
import com.bank.net.repository.BeneficiaryRepository;
import com.bank.net.repository.UserRepository;
import com.bank.net.service.AddBeneficiaryService;


@Service
public class AddBeneficiaryServiceImpl implements AddBeneficiaryService{

	private static final Logger logger = LoggerFactory.getLogger(AddBeneficiaryServiceImpl.class);
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	BeneficiaryRepository beneficiaryRepo;
	
	@Override
	public ResponseEntity<String> saveBeneficiary(BeneficiaryDTO benficiarydto, String userName) {
		logger.info("inside saveBeneficiary  method");
		logger.info("Checking if user exists.");
		User user = userRepo.findByUserName(userName);
		//System.out.println("user details are "+user.getUserID());
		if(user==null)
			throw new UserNotFoundException("Please enter a valid user name");
		Beneficiary benificary = new Beneficiary();
		benificary.setBeneficiaryAccountNo(Long.valueOf(benficiarydto.getBeneficiaryAccountNo()));
		benificary.setBeneficiaryName(benficiarydto.getBeneficiaryName());
		benificary.setIfsCode(benficiarydto.getIfscCode());
		benificary.setTransferLimit(Double.valueOf(benficiarydto.getTransferLimit()));
		benificary.setUser(user);
		beneficiaryRepo.save(benificary);
		return new ResponseEntity<>("Successfully added Beneficiary", HttpStatus.OK);
	}

}
