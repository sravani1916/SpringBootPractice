package com.bank.net.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.net.dto.BeneficiaryDTO;
import com.bank.net.service.AddBeneficiaryService;

@RestController
@RequestMapping(value ="/InternetBanking")
public class AddBeneficiaryController {

	private static final Logger logger = LoggerFactory.getLogger(AddBeneficiaryController.class);
	
	@Autowired
	AddBeneficiaryService addBeneficiaryService;
	
	@PostMapping("/{userName}")
	public ResponseEntity<?> saveBeneficiaryDetails(@Valid @RequestBody BeneficiaryDTO request,@PathVariable("userName") String userName)  
	{
    	logger.info("inside saveBeneficiaryDetails");
		return new ResponseEntity<>(addBeneficiaryService.saveBeneficiary(request,userName),HttpStatus.OK);
	}
    
}
