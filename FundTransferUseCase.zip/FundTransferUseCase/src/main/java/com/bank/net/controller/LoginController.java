package com.bank.net.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.net.dto.LoginDTO;
import com.bank.net.dto.UserDetailsDTO;
import com.bank.net.service.LoginService;

@RestController
@RequestMapping(value ="/InternetBanking")
public class LoginController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	LoginService loginService;
	
	@PostMapping("/login")
   	public ResponseEntity<?> getCustomerDetails(@Valid @RequestBody LoginDTO request)  
   	{
       	logger.info("inside checkCredentials");
   		return new ResponseEntity<>(loginService.getCustomerDetails(request),HttpStatus.OK);
   	}
    

}
