package com.bank.net.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.net.model.Beneficiary;


public interface BeneficiaryRepository extends JpaRepository<Beneficiary, Long>{
	
	Beneficiary findByBeneficiaryAccountNoAndUserUserID(long accountNo,long userid);

}
