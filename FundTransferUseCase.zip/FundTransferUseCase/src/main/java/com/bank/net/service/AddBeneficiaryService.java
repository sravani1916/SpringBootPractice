package com.bank.net.service;

import org.springframework.http.ResponseEntity;

import com.bank.net.dto.BeneficiaryDTO;

public interface AddBeneficiaryService {

	public ResponseEntity<String> saveBeneficiary(BeneficiaryDTO dto, String userName);
}
