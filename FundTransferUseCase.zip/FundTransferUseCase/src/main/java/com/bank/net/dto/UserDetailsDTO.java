package com.bank.net.dto;

public class UserDetailsDTO {
	
	private String firstname;
	private String lastname;
	private Long Accountno;
	private String accountType;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Long getAccountno() {
		return Accountno;
	}
	public void setAccountno(Long accountno) {
		Accountno = accountno;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	

}
