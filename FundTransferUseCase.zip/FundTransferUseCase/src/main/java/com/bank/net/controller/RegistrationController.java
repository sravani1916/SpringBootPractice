package com.bank.net.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.net.dto.UserRegDetailsDTO;
import com.bank.net.exception.UserAlreadyExistsException;
import com.bank.net.service.RegistrationService;

@RestController
@RequestMapping(value ="/InternetBanking")
public class RegistrationController {
	
	private static final Logger logger = LoggerFactory.getLogger(RegistrationController.class);

	@Autowired
	RegistrationService registrationService;
	
	@PostMapping("/Registration")
	public ResponseEntity<?> userRegistration(@Valid @RequestBody UserRegDetailsDTO request)  throws UserAlreadyExistsException
	{
    	logger.info("inside user registration");
		return new ResponseEntity<>(registrationService.saveCustomerDetails(request),HttpStatus.OK);
	}
	
}
