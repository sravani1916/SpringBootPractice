package com.bank.net;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundTransferUseCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundTransferUseCaseApplication.class, args);
	}

}
