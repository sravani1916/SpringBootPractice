package com.bank.net.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler{

	@ExceptionHandler(value = InSufficientBalanceException.class)
	   public ResponseEntity<Object> exception(InSufficientBalanceException exception) {
	      return new ResponseEntity<>("Balance is Insufficient in user Account", HttpStatus.NOT_FOUND);
	   }
	
	
	@ExceptionHandler(value = InvalidCredentialsException.class)
	   public ResponseEntity<Object> exception(InvalidCredentialsException exception) {
	      return new ResponseEntity<>("User Credentials are invalid", HttpStatus.NOT_FOUND);
	   }
	
	@ExceptionHandler(value = AccountNotFoundException.class)
	   public ResponseEntity<Object> exception(AccountNotFoundException exception) {
	      return new ResponseEntity<>("Account number not found", HttpStatus.NOT_FOUND);
	   }
	
	@ExceptionHandler(value = TransferLimitExceededException.class)
	   public ResponseEntity<Object> exception(TransferLimitExceededException exception) {
	      return new ResponseEntity<>("Transfer limit is exceeded, please enter a lesser amount", HttpStatus.NOT_FOUND);
	   }
	
	@ExceptionHandler(value = UserAlreadyExistsException.class)
	   public ResponseEntity<Object> exception(UserAlreadyExistsException exception) {
	      return new ResponseEntity<>("User already exists with same user name", HttpStatus.NOT_FOUND);
	   }

	@ExceptionHandler(value = UserNotFoundException.class)
	   public ResponseEntity<Object> exception(UserNotFoundException exception) {
	      return new ResponseEntity<>("User is not found", HttpStatus.NOT_FOUND);
	   }

	
}
