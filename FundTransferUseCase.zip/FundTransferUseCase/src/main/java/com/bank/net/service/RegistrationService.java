package com.bank.net.service;

import com.bank.net.dto.UserRegDetailsDTO;
import com.bank.net.exception.UserAlreadyExistsException;

public interface RegistrationService {
	
	public String saveCustomerDetails(UserRegDetailsDTO req) throws UserAlreadyExistsException;

}
