package com.bank.net.service;

import org.springframework.http.ResponseEntity;

import com.bank.net.dto.FundTransferDto;

public interface FundTransferService {

	public ResponseEntity<String> fundTransfer(FundTransferDto fundTransDto, String userName);
}
