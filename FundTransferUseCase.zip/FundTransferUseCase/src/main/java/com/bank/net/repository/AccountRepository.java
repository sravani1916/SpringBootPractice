package com.bank.net.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.net.model.Account;

public interface AccountRepository extends JpaRepository<Account, Long>{
	
	Long findByAccountNo(long accountNo);
	Account findByAccountNoAndUserUserID(long accountNo,long userid);

}
