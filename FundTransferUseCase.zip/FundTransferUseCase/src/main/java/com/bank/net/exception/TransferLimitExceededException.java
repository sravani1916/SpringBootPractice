package com.bank.net.exception;

public class TransferLimitExceededException extends RuntimeException {

	public TransferLimitExceededException()
	  {
		  super();
	  }
	  public TransferLimitExceededException(String message)
	  {
		  super(message);
	  }
	  
	  public TransferLimitExceededException(String message, Throwable t)
	  {
		  super(message,t);
	  }

}
