package com.bank.net.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class FundTransferDto {
	
	@Size(min = 5, max = 13)
	@NotNull(message="provide from account no ,only digits")
	@Pattern(regexp = "[0-9]{13}",message = "provide a valid from account no") 
	private String fromAcc;
	
	@Size(min = 5, max = 13)
	@NotNull(message="provide to account no ,only digits")
	@Pattern(regexp = "[0-9]{13}",message = "provide a valid to account no") 
	private String toAcc;
	private String remarks;
	
	@NotNull(message="provide transfer amount")
	@Pattern(regexp = "[0-9.#]+",message = "provide valid Transfer amount")
	private String transferAmount;
	
	public String getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(String fromAcc) {
		this.fromAcc = fromAcc;
	}
	public String getToAcc() {
		return toAcc;
	}
	public void setToAcc(String toAcc) {
		this.toAcc = toAcc;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(String transferAmount) {
		this.transferAmount = transferAmount;
	}
	
	
}
