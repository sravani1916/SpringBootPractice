package com.bank.net.service;

import org.springframework.http.ResponseEntity;

import com.bank.net.dto.LoginDTO;
import com.bank.net.dto.UserDetailsDTO;


public interface LoginService {
	
	public ResponseEntity<String> getCustomerDetails(LoginDTO request);

}
