package com.bank.net.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.net.model.UserCredentials;


public interface UserCredentialsRepository extends JpaRepository<UserCredentials, Long>{

	UserCredentials findByUserNameAndPassword(String userName, String password);
}
