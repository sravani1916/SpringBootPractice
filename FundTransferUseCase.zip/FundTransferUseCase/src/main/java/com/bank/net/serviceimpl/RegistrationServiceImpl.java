package com.bank.net.serviceimpl;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.net.dto.UserRegDetailsDTO;
import com.bank.net.exception.UserAlreadyExistsException;
import com.bank.net.model.Account;
import com.bank.net.model.User;
import com.bank.net.model.UserCredentials;
import com.bank.net.repository.AccountRepository;
import com.bank.net.repository.UserCredentialsRepository;
import com.bank.net.repository.UserRepository;
import com.bank.net.service.RegistrationService;
import com.bank.net.utility.CommonUtil;



@Service
public class RegistrationServiceImpl implements RegistrationService {

	private static final Logger logger = LoggerFactory.getLogger(RegistrationServiceImpl.class);
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	AccountRepository accountRepo;
	
	@Autowired
	UserCredentialsRepository userCredRepo;
	
	@Autowired
	CommonUtil commonUtil;
	
	@Override
	public String saveCustomerDetails(UserRegDetailsDTO request) throws UserAlreadyExistsException {
		logger.info("inside saveCustomerDetails  method");
		Date date = new Date();
		logger.info("Checking for if User Name exists.");
		if (Optional.ofNullable(userRepo.findByUserName(request.getUserName())).isPresent())
			throw new UserAlreadyExistsException("User Name already exists.Please try with another user name");
		User user = new User();
		user.setUserID(Long.valueOf(request.getUserid()));
		user.setUserName(request.getUserName());
		user.setFirstName(request.getFirstName());
		user.setLastName(request.getLastName());
		user.setMobileNo(Long.valueOf(request.getMobile()));
		user.setAccounttype(request.getAccountType());
		user.setAddress(request.getAddress());
		user.setEmailId(request.getEmail());
		userRepo.save(user);		
		logger.info("saved address and customer entities "+user.getUserID());
		String custId= user.getUserID().toString();
		System.out.println("User ID is "+custId);
		Account acc = new Account();
		acc.setAccountId(Long.valueOf(request.getAccountId()));
		long accountNo = Long.valueOf((custId+""+commonUtil.numbGen()).substring(0, 12));
		System.out.println("Account number is "+accountNo);
		acc.setAccountNo(accountNo);
		acc.setAccountType(request.getAccountType());
		acc.setAvailableBalance(Long.valueOf(request.getOpeningDeposit()));
		acc.setBankName(request.getBankName());
		acc.setBranchName(request.getBranchName());
		acc.setIfscCode(request.getIfscCode());
		acc.setUser(user);
		accountRepo.save(acc);
		logger.info("saved account details");
		
		UserCredentials userCred = new UserCredentials();
		userCred.setUser(user);
		userCred.setUserName(user.getUserName());		
		String strPwd  = acc.getAccountId() == null ? "":acc.getAccountId().toString() +UUID.randomUUID().toString().split("-")[1];
		userCred.setPassword(strPwd);
		userCredRepo.save(userCred);
		logger.info("saved user credentials entity");
		return "User AC Details Registered successfully";
	}

}
