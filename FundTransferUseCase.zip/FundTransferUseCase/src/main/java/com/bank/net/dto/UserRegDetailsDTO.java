package com.bank.net.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class UserRegDetailsDTO {
	
	private String userid;

	@NotEmpty(message = "provide user name for login")
	@Size(min = 4, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userName;
	
	@NotEmpty(message = "provide first name")
	@Size(min = 2, max = 20)
	@Pattern(regexp = "^[a-zA-Z0-9_ ]*$")
	private String firstName;
	
	@NotEmpty(message = "provide last name")
	@Size(min = 2, max = 20)
	@Pattern(regexp = "^[a-zA-Z0-9_ ]*$")
	private String lastName;
	

	@NotNull(message = "provide mobile no ,only digits")
	//@Pattern(regexp = "[0-9]{10}", message = "provide valid mobile no")
	private String mobile;
	
	@NotEmpty(message = "Provide email id")
	@Email
	private String email;
	
	@NotEmpty(message = "provide account type")
	@Size(min = 5, max = 10) // Value must contain at least 5 characters and a maximum of 10 characters
	@Pattern(regexp = "[a-zA-Z]+", message = "provide valid account type")
	private String accountType;
	private String address;
	private String accountId;
	//private Long accountNo;
	
	@NotNull(message = "provide opening deposit ,only digits")
	//@Pattern(regexp = "([^.\\d]+|[\\d+\\.]{2,})", message = "provide valid amount ")
	private String openingDeposit;
	private String availableBalance;
	
	@Size(min = 2, max = 25)
	@Pattern(regexp = "[a-zA-Z]+", message = "provide valid  Bank Name")
	@NotEmpty(message = "provide Bank Name")
	private String bankName;
	
	@Size(min = 5, max = 25)
	@Pattern(regexp = "[a-zA-Z]+", message = "provide valid  Branch Name")
	@NotEmpty(message = "provide Branch Name")
	private String branchName;
	
	@NotEmpty(message="provide IFSC Code")
	 @Size(min = 5, max = 15)
	 @Pattern(regexp = "[a-zA-Z0-9]+",message = "provide ifsCode")
	private String ifscCode;
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

	/*
	 * public Long getAccountNo() { return accountNo; } public void
	 * setAccountNo(Long accountNo) { this.accountNo = accountNo; }
	 */
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getOpeningDeposit() {
		return openingDeposit;
	}
	public void setOpeningDeposit(String openingDeposit) {
		this.openingDeposit = openingDeposit;
	}
	public String getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}
	
	
	
	

}
