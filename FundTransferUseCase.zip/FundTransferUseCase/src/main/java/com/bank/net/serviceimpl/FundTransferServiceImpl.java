package com.bank.net.serviceimpl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bank.net.dto.FundTransferDto;
import com.bank.net.exception.AccountNotFoundException;
import com.bank.net.exception.InSufficientBalanceException;
import com.bank.net.exception.TransferLimitExceededException;
import com.bank.net.exception.UserNotFoundException;
import com.bank.net.model.Account;
import com.bank.net.model.Beneficiary;
import com.bank.net.model.Transaction;
import com.bank.net.model.User;
import com.bank.net.repository.AccountRepository;
import com.bank.net.repository.BeneficiaryRepository;
import com.bank.net.repository.TransactionRepository;
import com.bank.net.repository.UserRepository;
import com.bank.net.service.FundTransferService;




@Service
public class FundTransferServiceImpl implements FundTransferService{
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	AccountRepository accountRepo;
	
	@Autowired
	BeneficiaryRepository beneficiaryRepo;
	
	@Autowired
	TransactionRepository transRepo;

	
	//Java 8 features Optional and -> (lambda) expressions implemented
	@Override
	public ResponseEntity<String> fundTransfer(FundTransferDto fundTransDto, String userName) {
		User user = Optional.ofNullable(userRepo.findByUserName(userName))
				.orElseThrow(() -> new UserNotFoundException("User is not valid"));
		
		Account fromAccDetails = Optional
				.ofNullable(accountRepo.findByAccountNoAndUserUserID(
						Long.valueOf(fundTransDto.getFromAcc()), user.getUserID()))
				.orElseThrow(() -> new AccountNotFoundException("Please enter a valid account number, Account number "+fundTransDto.getFromAcc()+" is invalid"));
		
		Beneficiary toAccDetails = Optional
				.ofNullable(beneficiaryRepo.findByBeneficiaryAccountNoAndUserUserID(
						Long.valueOf(fundTransDto.getToAcc()), user.getUserID()))
				.orElseThrow(() -> new AccountNotFoundException("Please enter a valid account number, Account number "+fundTransDto.getToAcc()+" is invalid"));

		if (Double.valueOf(fundTransDto.getTransferAmount()) > fromAccDetails.getAvailableBalance()) {
			throw new InSufficientBalanceException(
					"InSufficent balance for the account number::" + fromAccDetails.getAccountNo());
		}

		if (Double.valueOf(fundTransDto.getTransferAmount()) > toAccDetails.getTransferLimit()) {
			throw new TransferLimitExceededException("Transfer Limit Excessed for this benificary account number::"
					+ toAccDetails.getBeneficiaryAccountNo()+" Maximum tranfer Limit: "+toAccDetails.getTransferLimit());
		}
		
		Date date = new Date();
		Transaction sourceAcc = new Transaction();
		Transaction targetAcc = new Transaction();

		// inserting records to transactions tables for source account transaction
		Timestamp ts = new Timestamp(date.getTime());
		sourceAcc.setAmount(Double.valueOf(fundTransDto.getTransferAmount()));
		sourceAcc.setFromAccount(fromAccDetails.getAccountNo());
		sourceAcc.setTransactionTime(ts);
		sourceAcc.setTransactionType("Debit");
		sourceAcc.setRemarks(fundTransDto.getRemarks());
		System.out.println(" Source Ac amount  " +
		sourceAcc.getAmount() 
		+"  Source Ac NO " + sourceAcc.getFromAccount() 
		+ "  Source Ac Time " + sourceAcc.getTransactionTime() 
		+ "  Source Ac Remarks " + sourceAcc.getRemarks());
		transRepo.save(sourceAcc);

		// inserting records to transactions tables for target account transaction
		targetAcc.setAmount(Double.valueOf(fundTransDto.getTransferAmount()));
		targetAcc.setToAccount(toAccDetails.getBeneficiaryAccountNo());
		targetAcc.setTransactionTime(ts);
		targetAcc.setTransactionType("Credit");
		targetAcc.setRemarks(fundTransDto.getRemarks());
		transRepo.save(targetAcc);

		// updating the account details for the given account number
		if (Optional.ofNullable(transRepo).isPresent()) {
			fromAccDetails.setAvailableBalance(
					fromAccDetails.getAvailableBalance() - Double.valueOf(fundTransDto.getTransferAmount()));
			fromAccDetails.setOpeningDeposit(
					fromAccDetails.getOpeningDeposit() - Double.valueOf(fundTransDto.getTransferAmount()));
			accountRepo.save(fromAccDetails);
		}
		
		return new ResponseEntity<>("Transaction Done Successfully ", HttpStatus.OK);
	}

}
