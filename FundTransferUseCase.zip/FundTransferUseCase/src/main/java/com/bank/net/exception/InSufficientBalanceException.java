package com.bank.net.exception;

public class InSufficientBalanceException extends RuntimeException {

	public InSufficientBalanceException()
	  {
		  super();
	  }
	  public InSufficientBalanceException(String message)
	  {
		  super(message);
	  }
	  
	  public InSufficientBalanceException(String message, Throwable t)
	  {
		  super(message,t);
	  }

}
