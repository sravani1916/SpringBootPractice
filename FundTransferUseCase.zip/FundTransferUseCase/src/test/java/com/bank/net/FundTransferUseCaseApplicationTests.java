package com.bank.net;

import org.junit.jupiter.api.Test;


class FundTransferUseCaseApplicationTests {
	
	
	@Test
	void contextLoads() {
	}

}
