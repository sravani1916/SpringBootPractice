package com.bank.net.TestController;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bank.net.controller.AddBeneficiaryController;
import com.bank.net.controller.FundTransferController;
import com.bank.net.controller.LoginController;
import com.bank.net.controller.RegistrationController;
import com.bank.net.dto.BeneficiaryDTO;
import com.bank.net.dto.FundTransferDto;
import com.bank.net.dto.LoginDTO;
import com.bank.net.dto.UserDetailsDTO;
import com.bank.net.dto.UserRegDetailsDTO;
import com.bank.net.exception.InvalidCredentialsException;
import com.bank.net.exception.UserAlreadyExistsException;
import com.bank.net.exception.UserNotFoundException;
import com.bank.net.model.UserCredentials;
import com.bank.net.service.AddBeneficiaryService;
import com.bank.net.service.FundTransferService;
import com.bank.net.service.LoginService;
import com.bank.net.service.RegistrationService;

import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestAllFundTransferController {
	
	@Mock
	RegistrationService regService;
	
	@Mock
	LoginService loginService;
	
	@Mock
	FundTransferService fundTransferService;
	
	@Mock
	AddBeneficiaryService addBeneficiaryService;
	
	@InjectMocks
	RegistrationController regController;
	
	@InjectMocks
	LoginController loginController;
	
	@InjectMocks
	FundTransferController fundTransferController;
	
	@InjectMocks
	AddBeneficiaryController addBeneficiaryController;
	
	static LoginDTO loginDTO;
	static UserRegDetailsDTO userRegistrationDTO;
	static BeneficiaryDTO beneficiaryDTO;
	static FundTransferDto fundTransferDto;
	static UserDetailsDTO userDetailsDTO;
	
	@BeforeAll
	public void setUp() {
		loginDTO = new LoginDTO();
		loginDTO.setUsername("sravani");
		loginDTO.setPassword("sravani123");
		
		userRegistrationDTO = new UserRegDetailsDTO();
		userRegistrationDTO.setUserName("A12345");
		userRegistrationDTO.setFirstName("Sravani");
		userRegistrationDTO.setLastName("Dusetty");
		userRegistrationDTO.setAccountType("savings");
		userRegistrationDTO.setAddress("Hyderabad");
		userRegistrationDTO.setAvailableBalance("10000");
		userRegistrationDTO.setBankName("SBI");
		userRegistrationDTO.setBranchName("Uppal");
		userRegistrationDTO.setEmail("sravani.dusetty@gmail.com");
		userRegistrationDTO.setIfscCode("SBI0002345");
		userRegistrationDTO.setOpeningDeposit("0");
		userRegistrationDTO.setAccountId("723734273");
		//userRegistrationDTO.setAccountNo((long) 123455678);
		userRegistrationDTO.setMobile("987654321");
		userRegistrationDTO.setUserid("12345");
		
		userDetailsDTO = new UserDetailsDTO();
		userDetailsDTO.setAccountno((long) 11223344);
		userDetailsDTO.setAccountType("savings");
		userDetailsDTO.setFirstname("Vidhatri");
		userDetailsDTO.setLastname("sharma");
		
		beneficiaryDTO = new BeneficiaryDTO();
		beneficiaryDTO.setBeneficiaryAccountNo("221133");
		beneficiaryDTO.setBeneficiaryName("Vidhatri");
		beneficiaryDTO.setIfscCode("HDFC0009876");
		beneficiaryDTO.setTransferLimit("100000");
		
		fundTransferDto = new FundTransferDto();
		fundTransferDto.setFromAcc("123455678");
		fundTransferDto.setToAcc("221133");
		fundTransferDto.setTransferAmount("5000");
		fundTransferDto.setRemarks("test");
		
	}
	
	@Test
	@DisplayName("Login Function: Positive Scenario")
	@Order(1)
	public void testAuthenticateUserPositive()
	{
		//context
		when(loginService.getCustomerDetails(loginDTO)).thenReturn(new ResponseEntity<>("Login success", HttpStatus.OK));
		
		//Event
		ResponseEntity<?> result = loginController.getCustomerDetails(loginDTO);
		
		//out come
		assertEquals(HttpStatus.OK, result.getStatusCode());
	}
	
	@Test
	@DisplayName("Login Function: Negative Scenario")
	@Order(2)
	public void testAuthenticateUserNegative()
	{
		//context
		when(loginService.getCustomerDetails(loginDTO)).thenThrow(InvalidCredentialsException.class);
		
		//Event and out come
		assertThrows(InvalidCredentialsException.class,()->loginController.getCustomerDetails(loginDTO));
	}
	
	@Test
	@DisplayName("Registration Function: Positive Scenario")
	@Order(3)
	public void testRegistrationUserPositive() {
		
		when(regService.saveCustomerDetails(userRegistrationDTO)).thenReturn("User Registered successfully");
		
		ResponseEntity<?> result = regController.userRegistration(userRegistrationDTO);
		
		assertEquals(HttpStatus.OK, result.getStatusCode());
		
	}
	
	@Test
	@DisplayName("Registration Function : Negative Scenario")
	@Order(4)
	public void testRegistrationUserNegative() {
		// context
		when(regService.saveCustomerDetails(userRegistrationDTO)).thenThrow(UserAlreadyExistsException.class);
		// Event and outcome
		assertThrows(UserAlreadyExistsException.class,()-> regController.userRegistration(userRegistrationDTO));
	}
	
	@Test
	@DisplayName("Add Beneficiary : Positive Scenario")
	@Order(5)
	public void testAddBeneficiaryPositive() {
		when(addBeneficiaryService.saveBeneficiary(beneficiaryDTO, "B5678")).thenReturn(new ResponseEntity<>("Successfully added Beneficiary", HttpStatus.OK));
		
		assertEquals(HttpStatus.OK, addBeneficiaryController.saveBeneficiaryDetails(beneficiaryDTO, "B5678").getStatusCode());
	}
	
	@Test
	@DisplayName("Add Beneficiary : Negative Scenario")
	@Order(6)
	public void testAddBeneficiaryNegative() {
		when(addBeneficiaryService.saveBeneficiary(beneficiaryDTO, "B5678")).thenThrow(UserNotFoundException.class);
		
		assertThrows(UserNotFoundException.class, ()->addBeneficiaryService.saveBeneficiary(beneficiaryDTO, "B5678"));
	}
	
	@Test
	@DisplayName("Fund Transfer : Positive Scenario")
	@Order(7)
	public void testFundTransferPositive() {
		when(fundTransferService.fundTransfer(fundTransferDto, "C98765")).thenReturn(new ResponseEntity<>("Transaction Done Successfully", HttpStatus.OK));
		
		assertEquals(HttpStatus.OK, fundTransferController.fundTransfer(fundTransferDto, "C98765").getStatusCode());
	}
	
	@Test
	@DisplayName("Fund Transfer : Negative Scenario")
	@Order(8)
	public void testFundTransferNegative() {
		when(fundTransferService.fundTransfer(fundTransferDto, "C98765")).thenThrow(UserNotFoundException.class);
		
		assertThrows(UserNotFoundException.class, ()->fundTransferService.fundTransfer(fundTransferDto, "C98765"));
	}

}
