package com.bank.net.TestService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bank.net.dto.BeneficiaryDTO;
import com.bank.net.dto.FundTransferDto;
import com.bank.net.dto.LoginDTO;
import com.bank.net.dto.UserDetailsDTO;
import com.bank.net.dto.UserRegDetailsDTO;
import com.bank.net.exception.AccountNotFoundException;
import com.bank.net.exception.InvalidCredentialsException;
import com.bank.net.exception.UserAlreadyExistsException;
import com.bank.net.exception.UserNotFoundException;
import com.bank.net.model.Account;
import com.bank.net.model.Beneficiary;
import com.bank.net.model.Transaction;
import com.bank.net.model.User;
import com.bank.net.model.UserCredentials;
import com.bank.net.repository.AccountRepository;
import com.bank.net.repository.BeneficiaryRepository;
import com.bank.net.repository.TransactionRepository;
import com.bank.net.repository.UserCredentialsRepository;
import com.bank.net.repository.UserRepository;
import com.bank.net.serviceimpl.AddBeneficiaryServiceImpl;
import com.bank.net.serviceimpl.FundTransferServiceImpl;
import com.bank.net.serviceimpl.LoginServiceImpl;
import com.bank.net.serviceimpl.RegistrationServiceImpl;

@ExtendWith(MockitoExtension.class)
@RunWith(MockitoJUnitRunner.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestAllFundTransferService {

	@Captor
	private ArgumentCaptor<UserCredentials> postArgumentCaptor;

	@InjectMocks
	RegistrationServiceImpl regService;

	@InjectMocks
	LoginServiceImpl loginService;

	@InjectMocks
	FundTransferServiceImpl fundTransferService;

	@InjectMocks
	AddBeneficiaryServiceImpl addBeneficiaryService;

	@Mock
	UserCredentialsRepository userCredRepo;

	@Mock
	UserRepository userRepo;

	@Mock
	AccountRepository accRepo;

	@Mock
	BeneficiaryRepository beneficiaryRepo;

	@Mock
	TransactionRepository transRepo;

	static LoginDTO loginDTO;
	static UserRegDetailsDTO userRegistrationDTO;
	static BeneficiaryDTO beneficiaryDTO;
	static FundTransferDto fundTransferDto;
	static UserDetailsDTO userDetailsDTO;
	static User user;
	static Account account;
	static Beneficiary beneficiary;
	static Transaction transaction;
	static UserCredentials userCred;

	@BeforeAll
	public static void setUp() {

		loginDTO = new LoginDTO();
		loginDTO.setUsername("sravani");
		loginDTO.setPassword("12345");

		userRegistrationDTO = new UserRegDetailsDTO();
		userRegistrationDTO.setUserName("A12345");
		userRegistrationDTO.setFirstName("Sravani");
		userRegistrationDTO.setLastName("Dusetty");
		userRegistrationDTO.setAccountType("savings");
		userRegistrationDTO.setAddress("Hyderabad");
		userRegistrationDTO.setAvailableBalance("10000");
		userRegistrationDTO.setBankName("SBI");
		userRegistrationDTO.setBranchName("Uppal");
		userRegistrationDTO.setEmail("sravani.dusetty@gmail.com");
		userRegistrationDTO.setIfscCode("SBI0002345");
		userRegistrationDTO.setOpeningDeposit("0");
		// userRegistrationDTO.setAccountId((long) 723734273);
		// userRegistrationDTO.setAccountNo((long) 123455678);
		userRegistrationDTO.setMobile("987654321");
		userRegistrationDTO.setUserid("12345");

		userDetailsDTO = new UserDetailsDTO();
		userDetailsDTO.setAccountno(11223344l);
		userDetailsDTO.setAccountType("savings");
		userDetailsDTO.setFirstname("Vidhatri");
		userDetailsDTO.setLastname("sharma");

		beneficiaryDTO = new BeneficiaryDTO();
		beneficiaryDTO.setBeneficiaryAccountNo("221133");
		beneficiaryDTO.setBeneficiaryName("Vidhatri");
		beneficiaryDTO.setIfscCode("HDFC0009876");
		beneficiaryDTO.setTransferLimit("100000");

		fundTransferDto = new FundTransferDto();
		fundTransferDto.setFromAcc("123455678");
		fundTransferDto.setToAcc("221133");
		fundTransferDto.setTransferAmount("5000");
		fundTransferDto.setRemarks("test");

		user = new User();
		user.setUserID(15l);
		user.setUserName("Q11111");

		userCred = new UserCredentials();
		userCred.setUserName("sravani");
		userCred.setPassword("12345");

		account = new Account();
		account.setAvailableBalance(100000);
		account.setAccountNo(98675363l);

		beneficiary = new Beneficiary();
		beneficiary.setBeneficiaryAccountNo(73247872l);
		beneficiary.setUser(user);
		beneficiary.setTransferLimit(10000);

	}

	@Test
	@DisplayName("Login Credentials :: Postive Scenario")
	@Order(1)
	public void testAuthenticateUserPostive() {
		Mockito.when(userCredRepo.findByUserNameAndPassword("sravani", "12345")).thenReturn(userCred);
		// Event
		ResponseEntity<?> result = loginService.getCustomerDetails(loginDTO);
		// out come
		assertEquals(HttpStatus.OK, result.getStatusCode());
	}

	@Test
	@DisplayName("Login Credentials:: Negative Scenrio")
	@Order(2)
	public void testAuthenticateUserNegative() {
		// context
		Mockito.when(userCredRepo.findByUserNameAndPassword("sravani", "12345")).thenReturn(null);
		// Event and outcome
		assertThrows(InvalidCredentialsException.class, () -> loginService.getCustomerDetails(loginDTO));
	}

	@Test
	@DisplayName("Add Beneficiary   :: Postive Scenario")
	@Order(3)
	public void testAddBenificaryPositive() {
		// context
		Mockito.when(userRepo.findByUserName(user.getUserName())).thenReturn(user);
		// Event and out come
		assertEquals(HttpStatus.OK, addBeneficiaryService.saveBeneficiary(beneficiaryDTO, "Q11111").getStatusCode());
	}

	@Test
	@DisplayName("Add Beneficiary   :: Negative Scenario")
	@Order(4)
	public void testSaveBenificaryNegative() throws UserNotFoundException {
		Mockito.when(userRepo.findByUserName("Q11111")).thenReturn(null);
		// Event and out come
		assertThrows(UserNotFoundException.class,
				() -> addBeneficiaryService.saveBeneficiary(beneficiaryDTO, "Q11111"));
	}

	/*
	 * @Test
	 * 
	 * @DisplayName("Test FundTransfer Transaction :: Postive Scenario")
	 * 
	 * @Order(7) public void testFundTransferPositive() { // context
	 * Mockito.when(userRepo.findByUserName("A12345")).thenReturn(user);
	 * Mockito.when(accRepo.findByAccountNoAndUserUserID(Long.valueOf(98675363),
	 * 15l)).thenReturn(account);
	 * Mockito.when(beneficiaryRepo.findByBeneficiaryAccountNoAndUserUserID(Long.
	 * valueOf(73247872), 15l)).thenReturn(beneficiary);
	 * 
	 * //Event and out come assertEquals(HttpStatus.OK,
	 * fundTransferService.fundTransfer(fundTransferDto, "A12345").getStatusCode());
	 * 
	 * }
	 * 
	 * @Test
	 * 
	 * @DisplayName("Test FundTransfer Transaction :: Negative Scenario")
	 * 
	 * @Order(8) public void testFundTransferNegative() { // context
	 * Mockito.when(userRepo.findByUserName("A12345")).thenReturn(null);
	 * 
	 * 
	 * Mockito.when(accRepo.findByAccountNoAndUserUserID(Long.valueOf(98675363),
	 * 15l)).thenReturn(null);
	 * Mockito.when(beneficiaryRepo.findByBeneficiaryAccountNoAndUserUserID(
	 * Long.valueOf(73247872), 15l)).thenReturn(null);
	 * 
	 * 
	 * assertThrows(UserNotFoundException.class,
	 * ()->fundTransferService.fundTransfer(fundTransferDto, "A12345"));
	 * 
	 * 
	 * }
	 */
}
